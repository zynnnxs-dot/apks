# NDREXAN CINEMA — Android starter

Starter project Android dengan Kotlin + Jetpack Compose, tema hitam-merah minimalis, navigasi dasar, katalog demo, pencarian, favorit lokal selama aplikasi berjalan, dan layar awal untuk player, Watch Party, akun, serta admin.

## Status jujur

Ini **belum APK produksi** dan belum menyertakan file APK. Ini source starter yang disiapkan agar bisa dibangun lewat GitHub Actions. Player, subtitle, login sungguhan, room nobar realtime, dan backend admin masih perlu diimplementasikan sebelum rilis.

## Cara build lewat HP

1. Buat repository baru di GitHub bernama `ndrexan-cinema`.
2. Upload semua isi folder proyek ini ke root repository (bukan upload folder zip sebagai satu file).
3. Buka tab **Actions** di repository.
4. Jalankan workflow **Build NDREXAN CINEMA APK** atau tunggu workflow berjalan setelah push.
5. Jika sukses, buka hasil workflow dan unduh artifact `ndrexan-cinema-debug-apk`.
6. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`. Android mungkin meminta izin instalasi dari sumber ini.

## Catatan penting sebelum rilis

- Data katalog saat ini adalah data demo.
- Ganti URL video demo dengan media yang kamu miliki atau yang lisensinya mengizinkan pemutaran.
- Untuk TMDB, gunakan API key sendiri dan ikuti ketentuan TMDB. Jangan commit kredensial privat.
- Login, akun, favorit tersinkron, room nobar, dan admin perlu backend yang diamankan. Jangan menaruh service-role key atau password admin di APK.
- Untuk distribusi publik, siapkan signing key, privacy policy, dan uji perangkat.
