package id.ndrexan.cinema

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF09090B)
private val Panel = Color(0xFF17171B)
private val Red = Color(0xFFE53945)
private val Soft = Color(0xFFB8B8C0)
private val White = Color(0xFFF8F8FA)

data class Movie(val title: String, val year: String, val genre: String, val description: String)

private val demoMovies = listOf(
    Movie("Big Buck Bunny", "2008", "Animasi · Demo legal", "Film animasi pendek open movie yang dapat digunakan untuk pengujian pemutar."),
    Movie("Sintel", "2010", "Fantasi · Demo legal", "Film pendek Blender Foundation; pastikan mematuhi lisensi sumber saat distribusi."),
    Movie("Tears of Steel", "2012", "Sci-fi · Demo legal", "Film open movie untuk menguji alur katalog dan pemutaran.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinemaApp() }
    }
}

@Composable
fun CinemaApp() {
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Movie?>(null) }
    var query by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }
    var videoUrl by remember { mutableStateOf("https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }
    var saved by remember { mutableStateOf(setOf<String>()) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Ink, surface = Panel,
            onPrimary = White, onBackground = White, onSurface = White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(42.dp).background(Red, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("N", color = White, fontSize = 26.sp, fontWeight = FontWeight.Black) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NDREXAN", fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 19.sp)
                        Text("C I N E M A", color = Red, fontSize = 10.sp, letterSpacing = 3.sp)
                    }
                    Icon(Icons.Default.Search, "Cari", tint = Soft, modifier = Modifier.clickable { tab = "Cari" }.size(26.dp))
                }

                if (selected != null && !showPlayer) {
                    MovieDetail(
                        movie = selected!!,
                        isSaved = saved.contains(selected!!.title),
                        onSave = {
                            saved = if (saved.contains(selected!!.title)) saved - selected!!.title else saved + selected!!.title
                        },
                        onPlay = { showPlayer = true },
                        onBack = { selected = null }
                    )
                } else if (showPlayer && selected != null) {
                    PlayerSetup(
                        movie = selected!!,
                        url = videoUrl,
                        onUrl = { videoUrl = it },
                        onBack = { showPlayer = false }
                    )
                } else {
                    when (tab) {
                        "Cari" -> SearchScreen(query, { query = it }, demoMovies.filter { it.title.contains(query, true) || it.genre.contains(query, true) }) { selected = it }
                        "Favorit" -> MovieList("Favorit", demoMovies.filter { saved.contains(it.title) }, onMovie = { selected = it }, empty = "Film yang lu simpan bakal muncul di sini.")
                        "Nobar" -> WatchPartyScreen()
                        "Akun" -> AccountScreen()
                        "Admin" -> AdminScreen()
                        else -> HomeScreen(demoMovies, onMovie = { selected = it }, onExplore = { tab = "Cari" })
                    }
                }

                Spacer(Modifier.weight(1f, fill = false))
                NavigationBar(containerColor = Panel, contentColor = White) {
                    val nav = listOf(
                        Triple("Home", Icons.Default.Home, "Home"),
                        Triple("Cari", Icons.Default.Search, "Cari"),
                        Triple("Favorit", Icons.Default.Favorite, "Favorit"),
                        Triple("Nobar", Icons.Default.Groups, "Nobar"),
                        Triple("Akun", Icons.Default.Person, "Akun")
                    )
                    nav.forEach { (label, icon, key) ->
                        NavigationBarItem(
                            selected = tab == key,
                            onClick = { tab = key; selected = null; showPlayer = false },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Red, selectedTextColor = Red,
                                indicatorColor = Red.copy(alpha = 0.15f),
                                unselectedIconColor = Soft, unselectedTextColor = Soft
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(movies: List<Movie>, onMovie: (Movie) -> Unit, onExplore: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(
                Modifier.fillMaxWidth().background(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF351015), Panel)),
                    RoundedCornerShape(24.dp)
                ).padding(22.dp)
            ) {
                Text("YOUR NIGHT.\nYOUR CINEMA.", fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text("Cerita pilihan, dengan gaya NDREXAN.", color = Soft)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onExplore, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("Jelajahi film")
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
        item { Text("Pilihan buat lu", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(movies) { movie -> MovieRow(movie, onClick = { onMovie(movie) }) }
        item {
            Text("Katalog ini masih berisi contoh demo. Sambungkan API katalog dan sumber video berlisensi sebelum rilis.", color = Soft, fontSize = 12.sp)
        }
    }
}

@Composable
fun MovieList(title: String, movies: List<Movie>, onMovie: (Movie) -> Unit, empty: String = "Belum ada film.") {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (movies.isEmpty()) item { Text(empty, color = Soft) }
        items(movies) { MovieRow(it) { onMovie(it) } }
    }
}

@Composable
fun SearchScreen(query: String, onQuery: (String) -> Unit, movies: List<Movie>, onMovie: (Movie) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Cari film", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            label = { Text("Judul atau genre") }, singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, cursorColor = Red)
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(movies) { MovieRow(it) { onMovie(it) } }
        }
    }
}

@Composable
fun MovieRow(movie: Movie, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 72.dp, height = 94.dp).background(
            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Red.copy(alpha = .75f), Color(0xFF292930))),
            RoundedCornerShape(10.dp)
        ), contentAlignment = Alignment.Center) {
            Text("N", fontSize = 34.sp, fontWeight = FontWeight.Black, color = White)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(movie.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("${movie.year}  •  ${movie.genre}", color = Red, fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            Text(movie.description, color = Soft, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Soft)
    }
}

@Composable
fun MovieDetail(movie: Movie, isSaved: Boolean, onSave: () -> Unit, onPlay: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("← Kembali", color = Soft, modifier = Modifier.clickable { onBack() })
        Box(Modifier.fillMaxWidth().height(180.dp).background(
            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF55151D), Panel)),
            RoundedCornerShape(20.dp)
        ), contentAlignment = Alignment.Center) {
            Text("NDREXAN CINEMA", fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 21.sp)
        }
        Text(movie.title, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("${movie.year}  •  ${movie.genre}", color = Red)
        Text(movie.description, color = Soft)
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Icon(Icons.Default.PlayArrow, null)
            Text("Buka pemutar demo")
        }
        OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth()) {
            Icon(if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isSaved) "Hapus dari favorit" else "Simpan ke favorit")
        }
    }
}

@Composable
fun PlayerSetup(movie: Movie, url: String, onUrl: (String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("← Kembali", color = Soft, modifier = Modifier.clickable { onBack() })
        Text(movie.title, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Sumber video demo", color = Red)
        Text("Masukkan URL video langsung yang legal dan bisa diakses. URL halaman embed belum tentu bisa diputar sebagai file video.", color = Soft, fontSize = 13.sp)
        OutlinedTextField(
            value = url, onValueChange = onUrl, modifier = Modifier.fillMaxWidth(),
            label = { Text("URL MP4 / HLS") }, minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, cursorColor = Red)
        )
        Button(
            onClick = { /* Player implementation is intentionally staged for the next build step. */ },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Red)
        ) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Pemutar siap di tahap berikutnya") }
        Text("Subtitle eksternal, pilihan track, dan kontrol playback belum diaktifkan di starter ini.", color = Soft, fontSize = 12.sp)
    }
}

@Composable
fun WatchPartyScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Watch Party", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Nonton bareng, satu room.", color = Soft)
        var room by remember { mutableStateOf("") }
        OutlinedTextField(room, { room = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Kode room") }, singleLine = true)
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Gabung room (backend belum tersambung)") }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Buat room (backend belum tersambung)") }
        Text("Ini masih UI prototipe. Room realtime dan sinkronisasi video perlu backend serta konfigurasi akses.", color = Soft, fontSize = 12.sp)
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Akun", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Profil NDREXAN", color = Red)
        Text("Login, penyimpanan favorit lintas perangkat, dan sinkronisasi akun belum tersambung.", color = Soft)
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Login (backend belum tersambung)") }
    }
}

@Composable
fun AdminScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Admin katalog", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Area pengelolaan katalog", color = Red)
        Text("Untuk keamanan, panel admin produksi harus memakai autentikasi dan aturan server. Jangan menyimpan password admin di aplikasi.", color = Soft)
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Sambungkan backend admin pada tahap berikutnya") }
    }
}
